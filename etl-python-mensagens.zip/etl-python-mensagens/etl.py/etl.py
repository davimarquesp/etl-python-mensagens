
import pandas as pd

# 1️⃣ EXTRAÇÃO
df = pd.read_csv("data/input_usuarios.csv")

# 2️⃣ TRANSFORMAÇÃO
def gerar_mensagem(nome):
    return f"Olá {nome}, temos uma oferta especial para você!"

df["mensagem"] = df["nome"].apply(gerar_mensagem)

# 3️⃣ CARREGAMENTO
df.to_csv("data/output_mensagens.csv", index=False)

print("ETL concluído com sucesso!")
